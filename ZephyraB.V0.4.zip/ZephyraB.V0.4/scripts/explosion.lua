loadstring(game:HttpGet('https://raw.githubusercontent.com/unixetp/explosion/refs/heads/main/keysystem.lua'))()

-- key: YesKJ1230JJ